from django.urls import path
from .views import lista_produtos, detalhe_produtos, inicio, sobre, carrinho

from .views import (
    inicio, sobre, carrinho,
    lista_produtos, detalhe_produtos,
)

urlpatterns = [
    path('', inicio, name='inicio'),
    path('sobre/', sobre, name='sobre'),
    path('produtos/', lista_produtos, name='lista_produtos'),
    path('produtos/<int:id>/', detalhe_produtos, name='detalhe_produtos'),
    path('carrinho/', carrinho, name='carrinho'),
    path('produtos/<str:categoria_slug>/', lista_produtos, name='lista_produtos_por_categoria'),
]
