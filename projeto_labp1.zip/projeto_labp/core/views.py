from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from .models import Produto
from .forms import ProdutoForm

def inicio(request):
    categorias = Produto._meta.get_field('categoria').choices
    return render(request, 'core/inicio.html', {'categorias': categorias})

def sobre(request):
    return render(request, 'core/sobre.html')

@login_required
def carrinho(request):
    return render(request, 'core/carrinho.html')

def lista_produtos(request):
    produtos = Produto.objects.all()
    return render(request, 'core/lista_produtos.html', {'produtos': produtos})

def detalhe_produtos(request, id):
    produto = get_object_or_404(Produto, id=id)
    return render(request, 'core/detalhe_produtos.html', {'produto': produto})


def lista_produtos(request, categoria_slug=None):
    produtos = Produto.objects.all()
    categoria_selecionada = None

    if categoria_slug:
        produtos = produtos.filter(categoria=categoria_slug)
        choices = dict(Produto._meta.get_field('categoria').choices)
        categoria_selecionada = choices.get(categoria_slug)

    return render(request, 'core/lista_produtos.html', {
        'produtos': produtos,
        'categoria_selecionada': categoria_selecionada
    })

