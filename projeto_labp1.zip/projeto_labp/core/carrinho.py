from decimal import Decimal
from .models import Produto

class Carrinho:
    def __init__(self, request):
        self.session = request.session
        carrinho = self.session.get('carrinho')
        if not carrinho:
            carrinho = self.session['carrinho'] = {}
        self.carrinho = carrinho

    def adicionar(self, produto, quantidade=1):
        produto_id = str(produto.id)
        if produto_id not in self.carrinho:
            self.carrinho[produto_id] = {
                'preco': str(produto.preco), # Decimal precisa virar string no JSON
                'quantidade': 0
            }
        self.carrinho[produto_id]['quantidade'] += quantidade
        self.salvar()

    def remover(self, produto):
        produto_id = str(produto.id)
        if produto_id in self.carrinho:
            del self.carrinho[produto_id]
            self.salvar()

    def salvar(self):
        self.session.modified = True

    def __iter__(self):
        # Facilita listar os itens no HTML buscando os produtos reais do banco
        produto_ids = self.carrinho.keys()
        produtos = Produto.objects.filter(id__in=produto_ids)
        carrinho_copia = self.carrinho.copy()

        for produto in produtos:
            carrinho_copia[str(produto.id)]['produto'] = produto

        for item in carrinho_copia.values():
            item['preco'] = Decimal(item['preco'])
            item['total'] = item['preco'] * item['quantidade']
            yield item

    def obter_total(self):
        return sum(Decimal(item['preco']) * item['quantidade'] for item in self.carrinho.values())

