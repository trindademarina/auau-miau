from django.db import models

class Produto(models.Model):
    CATEGORIAS_CHOICES = [
        ('racoes', 'Racoes'),
        ('brinquedos', 'Brinquedos'),
        ('higiene', 'Higiene'),
        ('acessorios', 'Acessorios'),
        ('medicamentos', 'Medicamentos'),
        ('outros', 'Outros'),
    ]


    codigo = models.CharField(max_length=100)
    descricao = models.CharField(max_length=150)
    preco = models.FloatField()
    imagem = models.ImageField(upload_to='produtos/')
    disponivel = models.BooleanField(default=True)
    categoria = models.CharField(
        max_length=20,
        choices=CATEGORIAS_CHOICES,
        default='outros'
    )

def __str__(self):
    return self.codigo